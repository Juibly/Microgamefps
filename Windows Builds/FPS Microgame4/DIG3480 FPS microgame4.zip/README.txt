1. For the camera I decided to increase the near clipping plane from 0.1 to 0.8. This prevents the player from seeing through the floor but now allows them to see through walls when directly next to them. This lets the player look into the next room to see how many enemies are within and where they are.
2. For my first VFX asset I added a smoke effect that plays under the door when it swings open at the start of the level. For my second asset I placed a sparking energy effect on two of the street lights. This is to make them appear somewhat broken.

External Assets Used:
Stylized Smoke Effects Pack by Maiami Studio- assetstore.unity.com/packages/vfx/particles/fire-explosions/free-stylized-smoke-effects-pack-226406
Magic Effects by Hovl Studio- assetstore.unity.com/packages/vfx/particles/spells/magic-effects-free-247933
