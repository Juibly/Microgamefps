1. This was my first time using Unity but I do have some experience working with game engines and files in general. I used Godot for the final of one of my classes last semester and I'm used to working with files thanks to installing mods for videogames.

2. I didn't run into any major challenges when working on the microgame. In the beginning I accidentally skipped to step five of the tutorial but was able to quickly back out and get to step one. I enjoyed how easy it was to manipulate the aspects of the player's movement in the microgame.

Assets used: Food Props by Unity Technologies

Link to gameplay video: https://youtu.be/2WX5QTwCcNQ