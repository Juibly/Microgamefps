1. I made two changes to the main camera. The first was changing the film grain to large and increasing its intensity significantly. I then added an intense chromatic aberration to fit in with the VHS-like aesthetic created by the film grain.
2. For my first VFX asset I added a smoke effect that plays under the door when it swings open at the start of the level. For my second asset I placed a sparking energy effect on two of the street lights. This is to make them appear somewhat broken.

External Assets Used:
Stylized Smoke Effects Pack by Maiami Studio- assetstore.unity.com/packages/vfx/particles/fire-explosions/free-stylized-smoke-effects-pack-226406
Magic Effects by Hovl Studio- assetstore.unity.com/packages/vfx/particles/spells/magic-effects-free-247933
