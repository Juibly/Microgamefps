Change List-
Add 2 3D assets: The first 3D asset I added to the microgame was a Cheese at the end of a path which hides an enemy behind it. The other 3D asset I added was a mushroom in the middle of the center room which I gave collision.

Modify 2 sound effects: victory jingle and
The first sound effect I changed was the victory sound that plays upon destroying every enemy. I replaced the default sound effect with Sega Mega Drive/Genesis Victory Jingle by SpringSpring. I also replaced the blaster weapon’s shoot sound effect with a futuristic shotgun sound effect made by Michael Klier.

Modify 1 music element: I added an audio source to the scene which plays Glitchy Battle by 3xBlast as background music.

Credits-
Food Props by Unity Technologies: assetstore.unity.com/packages/3d/food-props-163295?srsltid=AfmBOoqe6ovAOFPpMUoe-opclBsZtEFJWemnrpmyLqD_OJO2_XjKznqm
Sega Mega Drive/Genesis Victory Jingle by SpringSpring: opengameart.org/content/sega-mega-drivegenesis-victory-jingle 
Futuristic Shotgun by Michael Klier: opengameart.org/content/futuristic-shotgun
Glitchy Battle by 3xBlast: opengameart.org/content/glitchy-battle

Link to video playthrough: www.youtube.com/watch?v=PhVb0IOUt6w

