1. The first animation I added was alongside the addition of a door at the start of the level. This door is animated to automatically open when the level begins. The second animation element I added was making the cheese already present in the level spin continuously.

2. The first lighting element I added was several street lamps along the edge of the area with he cheese. These street lamps have lights that create a yellow tinted glow in the area beneath them. The other lighting element I added was two spotlights pointing downwards from on top of the mushroom in the central room. The make a circle of orange light where they point on the ground.

External assets used:
Street Lamps by SpaceZeta- assetstore.unity.com/packages/3d/props/exterior/street-lamps-165658 
Spotlight and Structure by SpaceZeta- assetstore.unity.com/packages/3d/props/interior/spotlight-and-structure-141453 
Metal Door by SimViz- assetstore.unity.com/packages/3d/props/metal-door-5397 

